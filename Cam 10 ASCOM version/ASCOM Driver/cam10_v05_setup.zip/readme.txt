01/11/2015

Cam10 ASCOM driver v.0.5 Readme

Directory description:

Default installation directory: C:\Program Files\Common Files\ASCOM\Camera\cam10
FTD2XX_NET.dll  	NET interface for FTDI ftd2xx.dll
cam10_v05.dll   	Cam10 driver, high-level interaction with camera (C#, Visual Studio 2010 project)  
cam10ll05.dll   	Cam10 driver, low-level interaction with camera (Delphi 7 project)

Release history:

v.0.5  - [1] Overscan added

v.0.4  - [1] Fixed compatibility with SharpCap and Nebulosity
         [2] Histogram Stretching options added

v.0.3  - [1] FT_Read, FT_Write error handling

v.0.2  - [1] Fixed bug with memory leak in cam10ll02.dll
       - [2] Some code refactoring for long exposures
       - [3] UI improvement

v.0.1  - [1] Initial release for cam10

Known issues:
n/a

Requirements:
Installed FTDI D2XX Driver (http://www.ftdichip.com/Drivers/D2XX.htm, version 2.08.24)
Net Framework 3.5 SP1 (http://www.microsoft.com/en-us/download/details.aspx?id=25150)
ASCOM Platform 6 SP1 (http://ascom-standards.org/Downloads/Index.htm)

Supported OS: WinXP SP3 x32/x64, Win7 x32/x64, Win8 x32/x64

Installation instructions:
1) Install Net Framework 3.5 SP1 (http://www.microsoft.com/en-us/download/details.aspx?id=25150), install ASCOM 6 SP1 platform (http://ascom-standards.org/Downloads/Index.htm);
2) Connect cam10 to PC and install FTDI driver ver. 2.08.24 (http://www.ftdichip.com/Drivers/D2XX.htm); In Device Manager find 2 new devices: USB Serial Converter A, USB Serial Converter B, uncheck "Load VCP" checkbox in the device properties on Advanced tab;
3) Run cam10_v0.5_setup.exe, next-next-next
4) If cam10 is correctly flashed through MProg 3.5 (http://astroccd.org/2013/01/cam8_mprog_flashing/) you can connect cam10 like a ASCOM compatible camera to your software.

Uninstall instructions:
From Start-Control Panel-Add & Remove Programs select ASCOM cam10 Camera Driver 0.5 and click to Remove button.

Authors:
Camera hardware and low-level camera interaction - Gilmanov Rim, grim63 (at) yandex.ru
Camera high-level interaction with ASCOM - Vakulenko Sergiy, sergiy.vakulenko (at) gmail.com 
Additional information by this project you can find at www.astroccd.org